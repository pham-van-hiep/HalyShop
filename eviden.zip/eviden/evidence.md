## 患者検索
### 薬局運用
1. 全患者検索
   1. 画面の表示

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/zb.png" width="350">|<img src="../eviden/za.png" width="350">|

   2. カナ氏名検索の結果表示

   |場合|対応前|対応後|
   |-|-|-|
   |該当あり|<img src="../eviden/namehaveB.png" width="350">|<img src="../eviden/namehaveA.png" width="350">|
   |該当なし|<img src="../eviden/namedonthaveB.png" width="350">|<img src="../eviden/namedonthaveA.png" width="350">|

   3. 患者情報項目を左にスワイプする

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/swipeB.png" width="350">|<img src="../eviden/swipeA.png" width="350">|

   3.1 家族検索結果

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/fmlrb.png" width="350">|<img src="../eviden/fmlra.png" width="350">|

   3.2 家族検索結果

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/fmleb.png" width="350">|<img src="../eviden/fmlea.png" width="350">|

   3.3 Follow

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/fmlrb.png" width="350">|<img src="../eviden/fmlra.png" width="350">|

2. ID検索

   |場合|対応前|対応後|
   |-|-|-|
   |該当あり|<img src="../eviden/idhaveB.png" width="350">|<img src="../eviden/idhaveA.png" width="350">|
   |該当なし|<img src="../eviden/iddonthaveB.png" width="350">|<img src="../eviden/iddonthaveA.png" width="350">|

   2.1 患者情報項目を左にスワイプする

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/idswB.png" width="350">|<img src="../eviden/idswA.png" width="350">|

3. 入力保留

   |場合|対応前|対応後|
   |-|-|-|
   |該当あり(西暦)|<img src="../eviden/yohaveB.png" width="350">|<img src="../eviden/yohaveA.png" width="350">|
   |該当あり（和暦）|<img src="../eviden/wahaveB.png" width="350">|<img src="../eviden/wahaveA.png" width="350">|
   |該当なし|<img src="../eviden/seidonthaveB.png" width="350">|<img src="../eviden/seidonthaveA.png" width="350">|

   3.1 患者情報項目を左にスワイプする

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/seiswB.png" width="350">|<img src="../eviden/seiswA.png" width="350">|

4. 電話番号

   |場合|対応前|対応後|
   |-|-|-|
   |該当あり|<img src="../eviden/phonehaveB.png" width="350">|<img src="../eviden/phonehaveA.png" width="350">|
   |該当なし|<img src="../eviden/phonedonthaveB.png" width="350">|<img src="../eviden/phonedonthaveA.png" width="350">|

   4.1 患者情報項目を左にスワイプする

   |対応前|対応後|
   |-|-|
   |<img src="../eviden/phoneswB.png" width="350">|<img src="../eviden/phoneswA.png" width="350">|

5. 