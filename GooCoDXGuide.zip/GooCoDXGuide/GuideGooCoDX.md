## GooCo DX Installation Guide
1. Advance download(it was attached)
   1. GCS_Root_CA.cer
   2. gooco-client-test-040200.pfx
      1. <img src="../GooCoDXGuide/IMG_0026.PNG" width="300">
2. Install GCS Certificate to iPad device
   1. Tap to **GCS_Root_CA.cer** from downloaded file to install GCS certificate.
      1. <img src="../GooCoDXGuide/IMG_0027.PNG" width="300">
   2. On iPad device, go to Setting > General > VPN & Device Management then tap to **GCS Root CA**, tap to install and input iPad's device password. GCS Certificate will be install.
      1. <img src="../GooCoDXGuide/IMG100.PNG" width="300">
      2. <img src="../GooCoDXGuide/IMG_0028.PNG" width="300">
      3. <img src="../GooCoDXGuide/IMG_0029.PNG" width="300">
      4. <img src="../GooCoDXGuide/IMG_0030.PNG" width="300">
   3. Next step, go to General > About > Certificate Trust Settings then turn on GCS Root CA
      1. <img src="../GooCoDXGuide/IMG_0031.PNG" width="300">
3. Install Certificate to GooCo DX app
   1. Need to install
      1. **ルート証明書**(root certificate)
      2. **接続証明書**(connect certificate) in **GooCo設定** screen
      3. <img src="../GooCoDXGuide/IMG_0032.PNG" width="300">
      4. **ルート証明書**(root certificate) Installation
         1. To install **ルート証明書**, tap to button **証明書追加**(Add certificate) under the title.
         2. Select **GCS_Root_CA.cer** from iPad's files.
            1. <img src="../GooCoDXGuide/IMG_0033.PNG" width="300">
         3. This MSG will be show after installed **GCS_Root_CA.cer**
            1. <img src="../GooCoDXGuide/IMG_0034.PNG" width="300">
      5. **接続証明書**(connect certificate) Installation
         1. To install **接続証明書**, tap to button **証明書追加**(Add certificate) under the title.
         2. Select **gooco-client-test-040200.pfx** from iPad's files.
            1. <img src="../GooCoDXGuide/IMG_0035.PNG" width="300">
         3. Input password is ***password*** to first text box
         4. Input IPAddess is ***wcf.staging.gooco.cloud*** to second text box then tap to 確認(Confirm) button to done this installation.
            1. <img src="../GooCoDXGuide/IMG_0036.PNG" width="300">
         5. This MSG will be show after installed **接続証明書**
            1. <img src="../GooCoDXGuide/IMG_0037.PNG" width="300">
4. Input store information to download store data
   1. 企業番号: ***040200***
   2. 店舗番号: ***0001***
   3. IPAddress: ***wcf.staging.gooco.cloud***
      1. <img src="../GooCoDXGuide/IMG_0038.PNG" width="300">
   4. Tap to cloud button to download store data
      1. <img src="../GooCoDXGuide/IMG_0039.PNG" width="300"> 